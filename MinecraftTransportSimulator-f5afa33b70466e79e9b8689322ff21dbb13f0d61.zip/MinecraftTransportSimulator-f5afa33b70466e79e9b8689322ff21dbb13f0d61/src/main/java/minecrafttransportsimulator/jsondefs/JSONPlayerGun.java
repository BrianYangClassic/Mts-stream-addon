package minecrafttransportsimulator.jsondefs;

public class JSONPlayerGun extends AJSONPartProvider{
	
}
